using System;
using System.Collections.Generic;
namespace UML2
{
    public class MenuCatalog
    {   
        
    
    }
}