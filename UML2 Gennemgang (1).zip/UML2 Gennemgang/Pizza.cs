namespace UML2
{
    public class Pizza
    {
        
    }
}